<?php

class Cliente {
    public $nome;
    public $idade;
    public $endereço;
    public $numero;
    public $sexo;
    public $nacionalidade;
    public $CPF;
    public $estadoCivil;
    public $escolaridade;
    public $profissao;
    public $rendaMensal;
    
    

    public function cadastrar(){
        echo "Você está cadastrado no nosso sistema!";
    }
    
}

    $pessoa = new Cliente();

    $pessoa->cadastrar();
    $pessoa-> nome = ' nome: Jeferson Ribeiro';
    $pessoa-> idade = 'idade: 47';
    $pessoa-> endereço = 'endereço: R. Paraíba, bairro Francisco Roberto, nº798';
    $pessoa-> numero = ' numero: (18)99913-4533 ';
    $pessoa-> sexo = 'sexo: masculino';
    $pessoa-> nacionalidade = 'nacionalidade: brasileira';
    $pessoa-> CPF = 'CPF: 573.641.949-16';
    $pessoa-> estadoCivil = 'estado civil: casado ';
    $pessoa-> escolaridade = 'escolaridade: Ensino Superior completo';
    $pessoa-> profissao = 'profissão: CEO (diretor executivo)';
    $pessoa-> rendaMensal = 'renda mensal: R$ 127 mil';
    
    ?>