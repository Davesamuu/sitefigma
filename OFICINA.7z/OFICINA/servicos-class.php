<?php

class Serviços {
    public $servico;
    public $duracao;
    public $maoDeObra;
    public $desconto;
    public $precoFinal;

    public function consertar(){
        echo "As alterações no seu veículo foram realizadas!";
    }
}

$reparos = new Serviços();

$reparos->consertar();
$reparos->servico = 'serviço: Troca do kit de embreagem';
$reparos->duracao = 'duraçao: 4h20min';
$reparos->maoDeObra = 'mão de obra: R$ 400,00';
$reparos->desconto = 'desconto: 6,25% (R$ 25,00)';
$reparos->precoFinal = 'preço total: R$ 375,00';

?>