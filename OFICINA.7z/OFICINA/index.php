<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=>, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">


    <title>Document</title>
</head>
<body style="background-color: #828282;">
    
    <section class="container">
       <div class= banner>
          <img src= "imagens/banner.png" width="1505" height="460"></div><br><br><br>
    
    <div id="menu">
        <ul>
        <a href="galeria.html">GALERIA /</a>
        <a href="nossaequipe.html">NOSSA EQUIPE /</a>
        <a href="contato.html">CONTATE-NOS</a>

</section>



    <section class="container flex">
        <div class="item flex-item-1"> <br><strong>DADOS DO CLIENTE</strong><br><br>


        <?php
        
        include_once("cliente-class.php");


    echo "<br/>";
    echo "<br/>";
    
    echo $pessoa-> nome;
    echo "<br/>";
    echo $pessoa-> idade;
    echo "<br/>";
    echo $pessoa-> endereço;
    echo "<br/>";
    echo $pessoa-> numero;
    echo "<br/>";
    echo $pessoa-> sexo;
    echo "<br/>";
    echo $pessoa-> nacionalidade;
    echo "<br/>";
    echo $pessoa-> CPF;
    echo "<br/>";
    echo $pessoa-> estadoCivil;
    echo "<br/>";
    echo $pessoa-> escolaridade;
    echo "<br/>";
    echo $pessoa-> profissao;
    echo "<br/>";
    echo $pessoa-> rendaMensal;
    echo "<br/>";
    
    echo"<br/>";
    echo"<br/>";
    ?> 
    </div>
   
        <div class="item flex-item-1"> <br><strong>TIPO DE CARRO</strong><br><br>


<?php
        
        include_once("carro-class.php");


    echo "<br/>";
    echo "<br/>";
    
    echo $veiculos-> marca;
    echo "<br/>";
    echo $veiculos-> modelo;
    echo "<br/>";
    echo $veiculos-> ano;
    echo "<br/>";
    echo $veiculos-> cor;
    echo "<br/>";
    echo $veiculos-> placa;
    echo "<br/>";
    
    echo"<br/>";

    ?> 
    </div>
   
        <div class="item flex-item-1"> <br><strong>PEÇA UTILIZADA</strong><br><br>


<?php
        
        include_once("produtos-class.php");
        echo "<br/>";
        echo "<br/>";

    echo $nome-> nome;
    echo "<br/>";
    echo $nome-> cor;
    echo "<br/>";
    echo $nome-> tamanho;
    echo "<br/>";
    echo $nome-> formato;
    echo "<br/>";
    echo $nome-> textura;
    echo "<br/>";
    echo $nome-> material;
    echo "<br/>";
    echo $nome-> flexibilidade;
    echo "<br/>";
    echo $nome-> durabilidade;
    echo "<br/>";
    echo $nome-> marca;
    echo "<br/>";
    echo $nome-> preco;
    echo "<br/>";

    echo"<br/>";

    ?> 
    </div>
        <div class="item flex-item-1"> <br><strong>TIPO DE SERVIÇO REALIZADO</strong><br><br>


<?php
        
        include_once("servicos-class.php");


    echo "<br/>";
    echo "<br/>";
    
    echo $reparos-> servico;
    echo "<br/>";
    echo $reparos-> duracao;
    echo "<br/>";
    echo $reparos-> maoDeObra;
    echo "<br/>";
    echo $reparos-> desconto;
    echo "<br/>";
    echo $reparos-> precoFinal;
    echo "<br/>";
    
    echo"<br/>";

    ?> 
    </div>
    </section>

    <section class="container flex">
        <div class="item flex-item-1"> <br><strong>VALOR TOTAL (PEÇAS E SERVIÇO)</strong><br><br>

        <?php
    $peca = 4110;
    $servico = 375;
    $valorTotal = ($peca+$servico);

    echo "O valor total é de R$ ", $valorTotal;
    echo "<br/>";
    echo "<br/>";
    echo "Parcelamos em até 12 vezes sem juros no cartão!";

    ?>


</body>
</html>