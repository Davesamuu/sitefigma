<?php

class Produtos {
    public $nome;
    public $cor;
    public $tamanho;
    public $formato;
    public $textura;
    public $material;
    public $flexibilidade;
    public $durabilidade;
    public $marca;
    public $preco;
    

    public function substituirPeçaAntiga(){
        echo "Parabéns, você adquiriu um de nossos produtos!";
}
}

$nome = new Produtos ();

$nome-> substituirPeçaAntiga();
$nome->nome = 'nome: kit embreagem';
$nome->cor = 'cor: metálica/preta';
$nome->tamanho = 'tamanho: ----';
$nome->formato = 'formato: circular';
$nome->textura = 'textura: ----';
$nome->material = 'material: metal';
$nome->flexibilidade = 'não flexível';
$nome->durabilidade = 'Boa durabilidade';
$nome->marca = 'marca: Mopar';
$nome->preco = 'R$ 4.110,00';

?>