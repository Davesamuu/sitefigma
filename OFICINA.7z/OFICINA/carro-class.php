<?php

class Carro {
    public $marca;
    public $modelo;
    public $ano;
    public $cor;
    public $placa;

    public function registrar(){
        echo "Seu veículo foi registrado no nosso site!";
    }
}

$veiculos = new Carro();

$veiculos-> registrar(); 
$veiculos-> marca = 'marca: Jeep';
$veiculos-> modelo = 'modelo: Jeep Compass';
$veiculos-> ano = 'ano: 2022';
$veiculos-> cor = 'cor: branco';
$veiculos-> placa = 'placa: CYX-4322';

 ?>
